/* global connectedMode, showAlert, generarVisualizacionTicket, renderCajaViewBase */
'use strict';
(() => {
  if (!connectedMode) return;
  const el = id => document.getElementById(id);
  const financialKinds = ['PURCHASE', 'EDIT_PURCHASE', 'CANCEL_PURCHASE', 'EXPENSE', 'CANCEL_EXPENSE', 'SUPPLIER_PAYMENT', 'CUSTOMER_PAYMENT_VOID', 'SUPPLIER_PAYMENT_VOID', 'CASH_MANUAL'];
  let busy = false, quote = null, quoteInput = null, activeScope = null, currentCash = null, displayedCashSessions = [], salesFlow = 'DIRECT', activeOrderId = null, nextInvoiceNumber = null, pendingOrderDetails = new Map(), historySales = [], historySummaryRequest = 0, historyLoadFlight = null, historyLoadDirty = false, historySearchRequest = 0, historySearchTimer = null, saleDetailRevision = 0, pendingOrderDetailGuard = null;
  const state = () => window.PosRuntime.salesInput();
  const scope = () => { const s = state(); return 'posOperation_' + encodeURIComponent(window.POS_API_BASE_URL) + '_' + s.businessId + '_' + s.userId; };
  function pending() {
    const value = localStorage.getItem(scope());
    if (!value) return null;
    try { const result = JSON.parse(value); if (/^[a-f0-9-]{36}$/.test(result.key) && [...financialKinds, 'SALE', 'CANCEL', 'OPEN_CASH', 'CLOSE_CASH', 'PREPARE_ORDER', 'ORDER_CHARGE', 'ORDER_CANCEL', 'PAYMENT_CONFIRM', 'CUSTOMER_PAYMENT'].includes(result.kind)) return result; } catch { /* Invalid marker stays blocked until checked. */ }
    throw new Error('No se pudo leer la referencia de la operación pendiente.');
  }
  function cashMovementDescription(value) {
    return String(value || '').replace(/(·\s*)(CASH|CARD|TRANSFER|CREDIT)\b/g, (_, separator, method) => separator + ({ CASH: 'Efectivo', CARD: 'Tarjeta', TRANSFER: 'Transferencia', CREDIT: 'Crédito' })[method]);
  }
  function notice(text = '') { el('saleOperationMessage').textContent = text; el('saleOperationMessage').classList.toggle('hidden', !text); el('recoverSaleBtn').classList.toggle('hidden', !text); }
  function showPending() { if (pending()) notice('Hay una operación cuyo resultado debe comprobarse antes de volver a cobrar. Requiere conexión.'); else notice(); }
  function api(action) { return window.PosConnected.inventoryOperation(action); }
  async function pages(method, query = '') {
    return api(async (client, business) => {
      const list = []; let maxId = null;
      for (let offset = 0; ; offset += 100) {
        const values = await client[method](offset, maxId, query);
        if (!maxId && values.length) maxId = values[0].id;
        if (values.some(value => value.businessId !== business)) throw new window.PosApiError('INVALID_RESPONSE');
        list.push(...values); if (values.length < 100) return list;
      }
    });
  }
  function mappedSale(sale) {
    const credit = sale.paymentMethod === 'CREDIT';
    const rawDetail = typeof sale.detail === 'string' ? sale.detail : '';
    const historyMarker = sale.isHistorical && rawDetail.startsWith('Factura local:') ? rawDetail.indexOf(' ' + '\u00b7' + ' ') : -1;
    let customerDetail = rawDetail;
    if (sale.isHistorical && rawDetail.startsWith('Factura local:')) customerDetail = historyMarker < 0 ? '' : rawDetail.slice(historyMarker + 3);
    const originalInvoice = sale.originalInvoiceNumber === null || sale.originalInvoiceNumber === undefined ? '' : String(sale.originalInvoiceNumber).trim();
    const displayInvoice = /^\d+$/.test(originalInvoice) ? originalInvoice.padStart(6, '0') : originalInvoice;
    return { id: sale.id, businessId: sale.businessId, numero: sale.invoiceNumber, numeroVisual: sale.isHistorical ? displayInvoice || null : String(sale.invoiceNumber).padStart(6, '0'), historicaConectada: sale.isHistorical === true, origenHistorico: sale.isHistorical ? (sale.sourceBusinessName || (sale.sourceBusinessKey ? 'Origen ' + sale.sourceBusinessKey.slice(0, 8) : 'Origen sin identificar')) : null, sourceBusinessKey: sale.sourceBusinessKey || null, sourceSaleId: sale.sourceSaleId || null, vendedor: sale.seller, fecha: new Date(sale.createdAt).toLocaleString(), fechaTS: Date.parse(sale.createdAt), detalle: sale.detail || '-', detalleCliente: customerDetail, metodo: credit ? 'Crédito' : 'Contado', medioPago: sale.paymentMethod.toLowerCase(), cliente: credit ? sale.clientName : '-', clienteId: sale.clientId, vencimiento: sale.dueAt ? new Date(sale.dueAt).toLocaleDateString() : null, vencimientoTS: sale.dueAt ? Date.parse(sale.dueAt) : null, saldoPendiente: credit && sale.status === 'COMPLETED' ? Number(sale.total) : 0, tarifa: sale.priceType === 'RETAIL' ? 'Menudeo' : 'Mayoreo', subtotal: Number(sale.subtotal), descuentoPct: Number(sale.discountPercent), descuentoMonto: Number(sale.discount), total: Number(sale.total), anulada: sale.status === 'CANCELLED', motivoAnulacion: sale.cancelReason, conectado: true, estadoCaja: sale.cashStatus === 'PENDING' ? 'pendiente' : sale.cashStatus === 'CONFIRMED' ? 'confirmado' : 'no_aplica', cajaSessionId: sale.cashSessionId, items: sale.items.map(item => ({ id: item.productId, name: item.name, barcode: item.barcode, cantidad: Number(item.quantity), connectedSubtotal: Number(item.subtotal), retailPrice: Number(item.unitPrice), wholesalePrice: Number(item.unitPrice) })) };
  }
  const historyMoney = value => 'C$' + Number(value || 0).toFixed(2);
  function historyBound(day, exclusive = false) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(day || ''));
    if (!match) return null;
    const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    if (exclusive) date.setDate(date.getDate() + 1);
    return date.toISOString();
  }
  function setHistoryStatus(message = '') {
    const status = el('connectedHistoryStatus');
    if (!status) return;
    status.textContent = message;
    status.classList.toggle('hidden', !message);
  }
  function historySearchQuery() { return (el('historyInvoiceSearch')?.value || '').trim().slice(0, 100); }
  async function applyHistorySearch(query = historySearchQuery()) {
    const request = ++historySearchRequest;
    if (!query) { window.PosRuntime.clearSalesSearchResults(); setHistoryStatus(''); return true; }
    try {
      const matches = await pages('sales', query);
      if (request !== historySearchRequest || query !== historySearchQuery()) return false;
      window.PosRuntime.setSalesSearchResults(matches.map(mappedSale).reverse());
      setHistoryStatus('');
      return true;
    } catch (error) {
      if (request !== historySearchRequest) return false;
      setHistoryStatus(window.PosMessages.fromError(error, 'No se pudieron buscar las facturas. Inténtalo de nuevo.'));
      if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error);
      return false;
    }
  }
  function searchHistory() {
    clearTimeout(historySearchTimer);
    const query = historySearchQuery();
    historySearchTimer = setTimeout(() => { void applyHistorySearch(query); }, 180);
  }
  function renderHistoryList(id, entries, emptyText, renderEntry) {
    const list = el(id);
    if (!list) return;
    list.replaceChildren();
    const values = entries.length ? entries.map(renderEntry) : [emptyText];
    for (const value of values) {
      const item = document.createElement('li');
      item.textContent = value;
      list.append(item);
    }
  }
  function markHistorySummaryLoading() {
    for (const id of ['summaryTodaySales', 'summaryTotalSales', 'summaryCashSales', 'summaryCardSales', 'summaryTransferSales', 'summaryCreditSales', 'summaryTotalExpenses']) {
      const node = el(id); if (node) node.textContent = 'Cargando…';
    }
  }
  async function refreshHistorySummary(sales = historySales, reportRequest = null) {
    const request = ++historySummaryRequest;
    const range = window.PosPeriodFilters?.range('history') || { from: '', until: '' };
    if (range.error) { setHistoryStatus(range.error); return; }
    setHistoryStatus('Actualizando indicadores conectados…');
    try {
      const summaryResult = await (reportRequest || api(client => client.connectedReport(historyBound(range.from), historyBound(range.until, true))));
      if (summaryResult?.failure) throw summaryResult.failure;
      const report = summaryResult?.report || summaryResult;
      if (request !== historySummaryRequest) return;
      const now = new Date();
      const todayTotal = sales.reduce((sum, sale) => {
        const date = new Date(sale.fechaTS);
        return !sale.anulada && date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate() ? sum + Number(sale.total || 0) : sum;
      }, 0);
      const methods = new Map(report.sales.paymentMethods.map(row => [row.method, Number(row.total)]));
      const totals = {
        summaryTodaySales: todayTotal,
        summaryTotalSales: report.sales.total,
        summaryCashSales: methods.get('CASH') || 0,
        summaryCardSales: methods.get('CARD') || 0,
        summaryTransferSales: methods.get('TRANSFER') || 0,
        summaryCreditSales: methods.get('CREDIT') || 0,
        summaryTotalExpenses: Number(report.expenses.total) + Number(report.purchases.total)
      };
      for (const [id, value] of Object.entries(totals)) { const node = el(id); if (node) node.textContent = historyMoney(value); }
      const lowStock = report.inventory.products.filter(product => product.status === 'Bajo stock' || product.status === 'Agotado');
      renderHistoryList('lowStockList', lowStock, 'Sin alertas.', product => `${product.name}: ${product.stock} uds.`);
      renderHistoryList('topSellingList', report.sales.topProducts.slice(0, 5), 'Sin datos.', product => `${product.name}: ${Number(product.quantity)} uds.`);
      setHistoryStatus('');
    } catch (error) {
      if (request !== historySummaryRequest) return;
      historyDiagnostic('connected-report', error);
      for (const id of ['summaryTodaySales', 'summaryTotalSales', 'summaryCashSales', 'summaryCardSales', 'summaryTransferSales', 'summaryCreditSales', 'summaryTotalExpenses']) { const node = el(id); if (node) node.textContent = '—'; }
      renderHistoryList('lowStockList', [], 'No disponible sin autorización de Reportes.', value => value);
      renderHistoryList('topSellingList', [], 'No disponible sin autorización de Reportes.', value => value);
      setHistoryStatus(error.code === 'MODULE_FORBIDDEN' ? 'Los indicadores requieren autorización para Reportes. El historial de ventas sigue disponible.' : window.PosMessages.fromError(error, 'No se pudieron cargar los indicadores. Actualiza la pantalla e inténtalo de nuevo.'));
      if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error);
    }
  }
  // SOFTVENTAWEB_HISTORY_DIAGNOSTICS_V1:sales
  function historyDiagnosticsEnabled() {
    try { return new URLSearchParams(window.location.search).get('diag') === 'history'; }
    catch { return false; }
  }
  const historyErrorStages = new WeakMap();
  function historyDiagnostic(stage, error) {
    if (!historyDiagnosticsEnabled()) return;
    const code = /^[A-Z][A-Z0-9_]{0,63}$/.test(error?.code || '') ? error.code : error?.message === 'Negocio incorrecto' ? 'BUSINESS_SCOPE_MISMATCH' : 'JAVASCRIPT_EXCEPTION';
    const status = Number.isInteger(error?.status) && error.status >= 100 && error.status <= 599 ? error.status : null;
    const errorName = /^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(error?.name || '') ? error.name : 'Error';
    const stack = typeof error?.stack === 'string' ? error.stack : '';
    const location = stack.split(/\r?\n/).map(frame => {
      const match = /(?:^|[/\\])((?:connected-sales|connected-auth|api-client|app)\.js)(?:\?[^:\s)]*)?:(\d+):\d+/.exec(frame);
      return match ? match[1] + ':' + match[2] : null;
    }).find(Boolean) || null;
    console.warn('[SoftVentaWeb diagnostic] ' + JSON.stringify({ area: 'history', stage, code, status, errorName, location }));
  }
  function diagnoseHistoryRequest(stage, request) {
    return Promise.resolve(request).catch(error => {
      if (error && (typeof error === 'object' || typeof error === 'function')) historyErrorStages.set(error, stage);
      throw error;
    });
  }
  async function loadHistoryOnce() {
    let stage = 'history-range';
    try {
    const range = window.PosPeriodFilters?.range('history') || { from: '', until: '' };
    const reportRequest = range.error ? null : api(client => client.connectedReport(historyBound(range.from), historyBound(range.until, true)))
      .then(report => ({ report }), failure => ({ failure }));
    const [salesPage, historicalOrders] = await Promise.all([
      diagnoseHistoryRequest('sales-list', pages('sales')),
      diagnoseHistoryRequest('historical-orders', api(client => client.historicalOrders()))
    ]);
    stage = 'map-sales';
    const rows = salesPage.map(mappedSale).reverse();
    stage = 'store-sales';
    historySales = rows;
    stage = 'publish-sales-runtime';
    window.PosRuntime.setSales(rows);
    stage = 'history-search';
    clearTimeout(historySearchTimer);
    if (historySearchQuery()) await applyHistorySearch(historySearchQuery());
    else window.PosRuntime.clearSalesSearchResults();
    stage = 'render-historical-orders';
    const historicalOrdersBody = el('historicalOrdersTableBody');
    if (historicalOrdersBody) {
      if (!historicalOrders.length) fillEmpty(historicalOrdersBody, 6, 'Sin órdenes históricas.');
      else {
        historicalOrdersBody.replaceChildren();
        for (const order of historicalOrders) {
          const row = document.createElement('tr');
          const items = order.items.map(item => item.name + ' × ' + Number(item.quantity) + (item.priceSnapshotAvailable && item.estimatedSubtotal !== null ? ' · C$' + item.estimatedSubtotal : ' · Precio histórico no disponible')).join('; ');
          const status = order.status === 'CANCELLED' ? 'Anulada' : order.status === 'COMPLETED' ? 'Completada' : 'Pendiente';
          for (const value of [order.id, new Date(order.createdAt).toLocaleString(), status, order.seller || 'No identificado', items, historyMoney(order.estimatedTotal)]) {
            const cell = document.createElement('td'); cell.textContent = value; row.append(cell);
          }
          historicalOrdersBody.append(row);
        }
      }
    }
    stage = 'connected-report';
    await refreshHistorySummary(rows, reportRequest);
    } catch (error) {
      historyDiagnostic(historyErrorStages.get(error) || stage, error);
      throw error;
    }
  }
  async function loadHistory({ refresh = false } = {}) {
    if (historyLoadFlight) { if (refresh) historyLoadDirty = true; return historyLoadFlight; }
    const flight = (async () => {
      do { historyLoadDirty = false; await loadHistoryOnce(); } while (historyLoadDirty);
    })();
    historyLoadFlight = flight;
    try { return await flight; }
    finally { if (historyLoadFlight === flight) historyLoadFlight = null; }
  }
  async function refreshNextInvoiceNumber() {
    nextInvoiceNumber = await api(client => client.nextInvoiceNumber());
    const number = el('currentSaleNumber'); if (number) number.textContent = nextInvoiceNumber;
    return nextInvoiceNumber;
  }
  async function refreshNextInvoiceNumberAfterOperation() {
    try { await refreshNextInvoiceNumber(); }
    catch (error) {
      nextInvoiceNumber = null;
      const number = el('currentSaleNumber'); if (number) number.textContent = '—';
      if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error);
    }
  }
  function captureOrderDetailGuard() {
    const input = el('saleDetailInput');
    return input ? { revision: saleDetailRevision, value: input.value } : null;
  }
  function clearCreatedOrderDetail(order, guard) {
    const input = el('saleDetailInput');
    if (!input || !guard || saleDetailRevision !== guard.revision || input.value !== guard.value || typeof order?.detail !== 'string' || input.value.trim() !== order.detail.trim()) return;
    input.value = '';
  }
  async function completed(result, recovered = false) {
    if (result.kind === 'ORDER' && result.order && !result.sale) {
      clearCreatedOrderDetail(result.order, pendingOrderDetailGuard);
      pendingOrderDetailGuard = null;
    }
    if (result.kind === 'CASH_MANUAL') {
      el('cajaMovimientoMonto').value = ''; el('cajaMovimientoConcepto').value = '';
      if (window.PosConnected.canManageModule('cajaView')) await load('cajaView');
      showAlert((result.movement.direction === 'IN' ? 'Entrada' : 'Retiro') + ' de efectivo registrado.');
      document.dispatchEvent(new Event('connected:report-data-changed'));
      return;
    }
    if (result.kind === 'CUSTOMER_PAYMENT_VOID') {
      el('statementModal').classList.add('hidden');
      if (!el('clientsView').classList.contains('hidden')) await window.PosClients.load('clientsView');
      showAlert('Abono revertido. El saldo fue restituido.' + (result.payment.refundCashSessionId ? ' La devolución se registró en la caja actual; los cierres anteriores se conservan.' : ' No se modificó el efectivo físico.'));
      document.dispatchEvent(new Event('connected:report-data-changed'));
      return;
    }
    if (['PURCHASE', 'EDIT_PURCHASE', 'CANCEL_PURCHASE', 'SUPPLIER_PAYMENT', 'SUPPLIER_PAYMENT_VOID'].includes(result.kind)) {
      await window.PosPurchases.operationCompleted(result, recovered);
      document.dispatchEvent(new Event('connected:report-data-changed'));
      return;
    }
    if (result.kind === 'EXPENSE') {
      await window.PosExpenses.operationCompleted(result, recovered);
      document.dispatchEvent(new Event('connected:report-data-changed'));
      return;
    }
    if (result.sale || result.order) await refreshNextInvoiceNumberAfterOperation();
    if (result.kind === 'CONFIRM_PAYMENT' && result.payment) {
      const payment = result.payment, method = payment.paymentMethod === 'CARD' ? 'Tarjeta' : 'Transferencia';
      showAlert(method + ' confirmado para la factura #' + payment.invoiceNumber + ' por ' + result.movement.confirmedBy + '. No suma al efectivo físico esperado.');
      if (!el('clientsView').classList.contains('hidden')) await window.PosClients.load('clientsView');
    } else if (result.kind === 'CONFIRM_PAYMENT' && result.supplierPayment) {
      const payment = result.supplierPayment, method = payment.paymentMethod === 'CARD' ? 'Tarjeta' : 'Transferencia';
      showAlert(method + ' confirmado para el pago de ' + (result.movement.supplierName || 'proveedor') + (payment.invoiceNumber ? ' · factura ' + payment.invoiceNumber : '') + ' por ' + result.movement.confirmedBy + '. No reduce el efectivo físico esperado.');
      if (!el('payablesView').classList.contains('hidden')) await window.PosPurchases.load('payablesView');
      if (!el('suppliersView').classList.contains('hidden')) await window.PosPurchases.load('suppliersView');
    } else if (result.kind === 'CONFIRM_PAYMENT' && result.sale) {
      window.PosRuntime.publishSale(mappedSale(result.sale)); activeOrderId = null; quote = quoteInput = null;
      showAlert((result.movement.paymentMethod === 'CARD' ? 'Tarjeta' : 'Transferencia') + ' confirmado por ' + (result.movement.confirmedBy || result.sale.cashier) + ' el ' + new Date(result.movement.confirmedAt).toLocaleString() + '. No suma al efectivo físico esperado.');
    } else if (result.kind === 'CUSTOMER_PAYMENT' && result.payment) {
      el('paymentSaleModal').classList.add('hidden');
      const method = result.payment.paymentMethod === 'CASH' ? 'Efectivo registrado en Caja' : result.payment.paymentMethod === 'CARD' ? 'Tarjeta pendiente de confirmar en Caja' : 'Transferencia pendiente de confirmar en Caja';
      showAlert('Abono registrado para la factura #' + result.payment.invoiceNumber + '. ' + method + '.');
      if (!el('clientsView').classList.contains('hidden')) await window.PosClients.load('clientsView');
    } else if (result.sale) {
      const sale = mappedSale(result.sale);
      window.PosRuntime.publishSale(sale);
      if (result.kind === 'SALE') {
        clearConfirmedSaleDetail(result.sale.detail);
        window.PosRuntime.clearCart(); el('connectedCheckoutModal').classList.add('hidden'); quote = quoteInput = null; activeOrderId = null;
        generarVisualizacionTicket(sale, Number(result.sale.cashReceived || result.sale.total), Number(result.sale.changeAmount || 0), recovered);
      } else {
        el('anularVentaModal').classList.add('hidden');
        const notice = result.sale.paymentMethod === 'CASH'
          ? result.refundCashSessionId ? `Venta anulada. La devolución se registró en la caja #${result.refundCashSessionId}; la caja original #${result.sale.cashSessionId} conserva su cierre.` : 'Venta anulada. No había efectivo que devolver.'
          : result.sale.paymentMethod === 'CREDIT' ? 'Venta a crédito anulada. El saldo y el inventario fueron revertidos.'
          : 'Venta anulada. Stock repuesto. La devolución por tarjeta o transferencia debe realizarse fuera del POS por el mismo medio.';
        showAlert(notice);
      }
    try { await window.PosInventory.load('salesView', { refresh: true }); } catch (error) { if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error); else showAlert('La operación está confirmada. No se pudo actualizar el catálogo; vuelve a Ventas para consultarlo.'); }
    }
    if (result.kind === 'ABANDONED') showAlert('La operación no estaba registrada y quedó descartada en el servidor. Puedes preparar el cobro nuevamente.');
    if (result.order && !result.sale) {
      activeOrderId = null; quote = quoteInput = null; el('connectedCheckoutModal').classList.add('hidden');
      const nextInvoiceNotice = nextInvoiceNumber ? ' La próxima factura sigue siendo #' + nextInvoiceNumber + '.' : '';
      if (result.kind === 'ORDER') { window.PosRuntime.clearCart(); showAlert('Orden enviada a Caja. No se generó factura ni se descontó inventario.' + nextInvoiceNotice); }
      else if (result.kind === 'CANCEL_ORDER') showAlert('Orden cancelada. No se generó factura ni movimiento de caja.' + nextInvoiceNotice);
    }
    if (result.cash) el('cierreCajaModal').classList.add('hidden');
    if (window.PosConnected.canManageModule('cajaView')) await load('cajaView');
    if (result.cash) showAlert(result.kind === 'OPEN_CASH' ? 'Caja abierta.' : 'Caja cerrada.');
    if (result.sale || result.payment || result.supplierPayment || result.cash || result.order) document.dispatchEvent(new Event('connected:report-data-changed'));
  }
  function clearConfirmedSaleDetail(detail) {
    const input = el('saleDetailInput'), expected = String(detail ?? '').trim();
    if (!input || input.value.trim() !== expected) return;
    try {
      if (typeof window.PosRuntime?.clearSaleDetail === 'function') {
        window.PosRuntime.clearSaleDetail(detail);
        if (input.value.trim() !== expected) return;
      }
    } catch { /* The server has confirmed the sale; use the same-value fallback below. */ }
    if (input.value.trim() === expected) input.value = '';
  }
  const isConfirmedSale = result => result?.kind === 'SALE' && result.sale?.status === 'COMPLETED';
  function lockConfirmedSaleCheckout() {
    activeOrderId = null; quote = quoteInput = null;
    el('connectedCheckoutModal')?.classList.add('hidden');
  }
  async function completeCommittedResult(result, recovered = false) {
    const confirmedSale = isConfirmedSale(result);
    if (confirmedSale) lockConfirmedSaleCheckout();
    try { await completed(result, recovered); }
    catch {
      if (confirmedSale) {
        lockConfirmedSaleCheckout();
        clearConfirmedSaleDetail(result.sale.detail);
        try { window.PosRuntime.clearCart(); } catch { /* The server result remains authoritative. */ }
        await Promise.allSettled([load('cajaView'), loadHistory({ refresh: true })]);
        document.dispatchEvent(new Event('connected:report-data-changed'));
        showAlert('Cobro confirmado para la factura #' + result.sale.invoiceNumber + '. No se pudo actualizar el comprobante; consulta el Historial. No vuelvas a cobrar esta orden.');
        return;
      }
      showAlert('El servidor confirmo la operacion, pero la pantalla no termino de actualizarse. Comprueba su estado antes de volver a intentarlo.');
    }
  }
  // These explicit schema rejections roll back the transaction and never commit money.
  const uncertain = error => !['SUPPLIER_PAYMENT_MIGRATION_REQUIRED', 'PROCUREMENT_MIGRATION_REQUIRED', 'SALES_MIGRATION_REQUIRED'].includes(error.code) && (error.status >= 500 || ['NETWORK_ERROR', 'INVALID_RESPONSE', 'STALE_REQUEST', 'INVALID_SESSION'].includes(error.code));
  async function perform(kind, data, action) {
    // Serialize check + marker creation across tabs without queuing another operation.
    if (globalThis.navigator?.locks) return navigator.locks.request(scope(), { ifAvailable: true }, lock => lock ? performWithMarker(kind, data, action) : showAlert('Hay una operación financiera en curso en otra pestaña. Espera su resultado o comprueba la operación pendiente.'));
    return performWithMarker(kind, data, action);
  }
  async function performWithMarker(kind, data, action) {
    if (busy) return;
    if (pending()) { showPending(); showAlert('Comprueba la operacion pendiente antes de iniciar otra.'); return; }
    busy = true; const marker = { key: crypto.randomUUID(), kind }; const storage = scope();
    data.operationKey = marker.key;
    try { localStorage.setItem(storage, JSON.stringify(marker)); } catch { busy = false; showAlert('No se pudo guardar la referencia del cobro. Habilita el almacenamiento del navegador antes de cobrar. No se envio la operacion.'); return; }
    showPending();
    try {
      let result;
      try { result = await api(client => action(client, data)); }
      catch (error) {
        if (!uncertain(error)) { try { localStorage.removeItem(storage); } catch { /* Keep the operation blocked if storage cannot be updated. */ } if (kind === 'PREPARE_ORDER') pendingOrderDetailGuard = null; }
        if (error.code === 'STALE_REQUEST') return;
        if (kind === 'ORDER_CHARGE' && error.code === 'ORDER_NOT_PENDING') {
          activeOrderId = null; quote = quoteInput = null;
          el('connectedCheckoutModal').classList.add('hidden');
          const refreshResults = await Promise.allSettled([load('cajaView'), loadHistory({ refresh: true })]);
          const refreshed = refreshResults.every(value => value.status === 'fulfilled');
          showAlert(refreshed
            ? 'La orden ya no esta pendiente. Caja e Historial se actualizaron; verifica si quedo cobrada o cancelada antes de continuar.'
            : 'La orden ya no esta pendiente y no se pudo completar la actualizacion de Caja e Historial. Verifica su estado antes de intentar otro cobro.');
          showPending();
          return;
        }
        if (uncertain(error)) {
          for (const id of ['connectedCheckoutModal','anularVentaModal','cierreCajaModal','purchaseModal','paymentInvoiceModal','statementModal','cancelConnectedPurchaseModal']) el(id).classList.add('hidden');
          notice('Resultado desconocido. Comprueba esta operacion antes de intentar cobrar nuevamente; podria estar confirmada.');
        }
        if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error);
        else {
          const safeMessage = window.PosMessages.fromError(error, 'No se pudo completar la operacion. Revisa su estado antes de volver a intentarlo.');
          if (['CASH_INVALID', 'CASH_INSUFFICIENT'].includes(error.code)) window.PosValidation.field('connectedCashReceived', safeMessage);
          showAlert(safeMessage + (uncertain(error) ? ' Comprueba el estado de la operacion antes de cobrar nuevamente.' : ''));
        }
        showPending();
        return;
      }
      if (isConfirmedSale(result)) lockConfirmedSaleCheckout();
      let markerRemoved = false;
      try { localStorage.removeItem(storage); markerRemoved = true; } catch { /* Keep the idempotency key available for recovery. */ }
      if (markerRemoved) notice(); else showPending();
      await completeCommittedResult(result);
    } finally { busy = false; }
  }
  async function recover() {
    if (busy) return;
    const marker = pending(); if (!marker) { notice(); return; }
    if (marker.kind === 'PREPARE_ORDER' && !pendingOrderDetailGuard) pendingOrderDetailGuard = captureOrderDetailGuard();
    busy = true; const storage = scope();
    try {
      // Locking resolver commits a tombstone if absent, rejecting any delayed request.
      const result = await api(client => financialKinds.includes(marker.kind) ? client.resolveFinancialOperation(marker.key, marker.kind) : client.resolveOperation(marker.key));
      let markerRemoved = false;
      try { localStorage.removeItem(storage); markerRemoved = true; } catch { /* Preserve the key for another safe reconciliation. */ }
      if (markerRemoved) notice(); else showPending();
      await completeCommittedResult(result, true);
    } catch (error) { window.PosConnected.handleError(error); showPending(); }
    finally { busy = false; }
  }
  function cartData(input = state()) {
    return { items: input.items, priceType: input.priceType, discountPercent: input.discountPercent, paymentMethod: input.paymentMethod, clientId: input.clientId, detail: input.detail };
  }
  function quoteData(input) {
    return { items: input.items, priceType: input.priceType, discountPercent: input.discountPercent, paymentMethod: input.paymentMethod, clientId: input.clientId };
  }
  function renderCheckoutItems(items) {
    const container = el('connectedCheckoutItems'); container.replaceChildren();
    for (const item of items) {
      const row = document.createElement('div'), description = document.createElement('span'), subtotal = document.createElement('span'), label = document.createElement('small'), amount = document.createElement('strong');
      row.className = 'checkout-item'; row.setAttribute('role', 'listitem');
      description.className = 'checkout-item-description'; description.textContent = item.name + ' × ' + Number(item.quantity);
      subtotal.className = 'checkout-item-subtotal'; label.textContent = 'Subtotal'; amount.textContent = 'C$' + item.total;
      subtotal.append(label, amount); row.append(description, subtotal); container.append(row);
    }
  }
  async function viewInvoice(id) {
    const sale = await api(client => client.sale(id));
    generarVisualizacionTicket(mappedSale(sale), Number(sale.cashReceived || sale.total), Number(sale.changeAmount || 0), false);
  }
  function updateCashChangePreview() {
    const preview = el('connectedCashChangePreview'), input = el('connectedCashReceived');
    if (!preview || !input) return;
    const received = Number(input.value), total = Number(quote?.total);
    if (quote?.paymentMethod !== 'CASH' || !input.value || !Number.isFinite(received) || received < total) { preview.classList.add('hidden'); return; }
    el('connectedCashChangeAmount').textContent = 'C$' + Math.max(0, received - total).toFixed(2);
    preview.classList.remove('hidden');
  }
  async function checkout() {
    if (busy) return;
    if (pending()) { showPending(); showAlert('Comprueba la operación pendiente antes de cobrar nuevamente.'); return; }
    const input = state();
    if (!input.items.length) { showAlert('El carrito está vacío. Agrega productos antes de cobrar.'); el('barcodeInput').focus(); return; }
    if (input.paymentMethod === 'CREDIT' && !input.clientId) { showAlert('Selecciona un cliente para vender a crédito'); return; }
    if (document.querySelector('input[name="descApplies"][value="si"]').checked && !window.PosValidation.validate(el('descuentoBox'), true)) return;
    if (salesFlow === 'CENTRALIZED') {
      pendingOrderDetailGuard = captureOrderDetailGuard();
      await perform('PREPARE_ORDER', { items: input.items, priceType: input.priceType, discountPercent: input.discountPercent, detail: input.detail, clientId: input.clientId }, (client, data) => client.prepareOrder(data));
      return;
    }
    activeOrderId = null; busy = true;
    try {
      quoteInput = cartData(input); quote = await api(client => client.quoteSale(quoteData(quoteInput)));
      el('connectedCheckoutTotal').textContent = 'C$' + quote.total;
      const method = quote.paymentMethod === 'CASH' ? 'Efectivo' : quote.paymentMethod === 'CARD' ? 'Tarjeta' : quote.paymentMethod === 'TRANSFER' ? 'Transferencia' : 'Crédito';
      el('connectedCheckoutPaymentMethod').textContent = method;
       el('connectedCheckoutDetail').textContent = quote.paymentMethod === 'CREDIT' ? 'Cliente: ' + quote.clientName + ' · Vence: ' + new Date(quote.dueAt).toLocaleDateString() + ' · No genera movimiento de efectivo.' : 'Subtotal C$' + quote.subtotal + ' · Descuento C$' + quote.discount;
      renderCheckoutItems(quote.items);

      el('connectedOrderMethodGroup').classList.add('hidden'); el('connectedPriceChangeMessage').classList.add('hidden');
      el('connectedCashGroup').classList.toggle('hidden', quote.paymentMethod !== 'CASH'); el('connectedCashReceived').value = ''; updateCashChangePreview(); window.PosValidation.clear(el('connectedCheckoutModal'));
      if (quote.paymentMethod === 'CARD' || quote.paymentMethod === 'TRANSFER') {
        const data = { ...quoteInput, quoteToken: quote.quoteToken, cashReceived: null };
        busy = false; await perform('SALE', data, (client, saleInput) => client.createSale(saleInput)); return;
      }
      el('connectedCheckoutTitle').textContent = quote.paymentMethod === 'CREDIT' ? 'Confirmar venta a crédito' : 'Cobro en Efectivo';
      el('confirmConnectedSaleBtn').textContent = quote.paymentMethod === 'CREDIT' ? 'Facturar a crédito' : 'Cobrar';
      el('connectedCheckoutModal').classList.remove('hidden');
      (quote.paymentMethod === 'CASH' ? el('connectedCashReceived') : el('confirmConnectedSaleBtn')).focus();
    } catch (error) { showAlert(window.PosMessages.fromError(error, 'No se pudo completar la operación. Inténtalo de nuevo.')); if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error); }
    finally { busy = false; }
  }
  async function confirm() {
    if (activeOrderId) {
      if (!quote || busy) return;
      const method = quote.paymentMethod, received = method === 'CASH' ? el('connectedCashReceived').value : null;
      if (method === 'CASH' && (!/^\d+(?:\.\d{1,2})?$/.test(received) || Number(received) < Number(quote.total))) { window.PosValidation.field('connectedCashReceived', 'Ingresa efectivo suficiente, con hasta dos decimales'); return; }
      const id = activeOrderId;
      await perform('ORDER_CHARGE', { quoteToken: quote.quoteToken, paymentMethod: method, cashReceived: received }, (client, input) => client.chargeOrder(id, input));
      return;
    }
    if (!quote || !quoteInput || busy) return;
    const data = { ...quoteInput, quoteToken: quote.quoteToken, cashReceived: quote.paymentMethod === 'CASH' ? el('connectedCashReceived').value : null };
    if (quote.paymentMethod === 'CASH' && (!/^\d+(?:\.\d{1,2})?$/.test(data.cashReceived) || Number(data.cashReceived) < Number(quote.total))) { window.PosValidation.field('connectedCashReceived', 'Ingresa efectivo suficiente, con hasta dos decimales'); return; }
    await perform('SALE', data, (client, input) => client.createSale(input));
  }
  async function cancel() {
    const id = el('anularVentaId').value, reason = el('anularVentaMotivo').value.trim();
    if (!id) { showAlert('Selecciona una venta del historial para anular.'); return; }
    if (!reason) { window.PosValidation.field('anularVentaMotivo', 'Ingresa el motivo de anulación'); return; }
    await perform('CANCEL', { reason }, (client, input) => client.cancelSale(id, input));
  }
  function renderCheckoutMode() {
    const button = el('processSaleBtn');
    if (button) button.textContent = salesFlow === 'CENTRALIZED' ? 'Enviar a Caja' : 'Procesar / Cobrar Venta';
    const label = el('currentSaleNumberLabel');
    if (label) label.textContent = 'Próxima factura #';
    el('currentSaleNumber').textContent = nextInvoiceNumber || '—';
  }
  async function startOrderCharge(id) {
    if (busy || pending()) { showPending(); showAlert('Comprueba la operación pendiente antes de continuar.'); return; }
    activeOrderId = String(id); quoteInput = null; const order = pendingOrderDetails.get(String(id));
    const methodSelect = el('connectedOrderPaymentMethod'), creditOption = [...methodSelect.options].find(option => option.value === 'CREDIT');
    methodSelect.value = order?.clientId ? 'CREDIT' : 'CASH'; methodSelect.disabled = Boolean(order?.clientId); if (creditOption) creditOption.disabled = !order?.clientId;
    await refreshOrderQuote();
  }
  async function refreshOrderQuote() {
    if (!activeOrderId || busy) return;
    busy = true; el('confirmConnectedSaleBtn').disabled = true;
    let refreshed = false;
    try {
      quote = await api(client => client.quoteOrder(activeOrderId, el('connectedOrderPaymentMethod').value));
      el('connectedCheckoutTitle').textContent = 'Cobrar orden';
      renderCheckoutItems(quote.items);

      el('connectedCheckoutTotal').textContent = 'C$' + quote.total;
      const method = quote.paymentMethod === 'CASH' ? 'Efectivo' : quote.paymentMethod === 'CARD' ? 'Tarjeta' : quote.paymentMethod === 'TRANSFER' ? 'Transferencia' : 'Crédito';
      el('connectedCheckoutPaymentMethod').textContent = method;
       el('connectedCheckoutDetail').textContent = quote.paymentMethod === 'CREDIT' ? 'Cliente: ' + quote.clientName + ' · Vence: ' + new Date(quote.dueAt).toLocaleDateString() + ' · Sin ingreso de efectivo.' : 'Subtotal C$' + quote.subtotal + ' · Descuento C$' + quote.discount;
      const difference = Number(quote.priceDelta), priceMessage = el('connectedPriceChangeMessage');
      priceMessage.textContent = quote.priceChanged ? 'El precio cambió desde que se preparó la orden: estimado C$' + quote.estimatedTotal + '; precio vigente C$' + quote.total + ' (' + (difference > 0 ? '+' : '') + 'C$' + quote.priceDelta + '). Confirma este precio vigente para continuar.' : 'Precio vigente comprobado. Total estimado al preparar: C$' + quote.estimatedTotal + '.';
      priceMessage.classList.remove('hidden'); el('connectedOrderMethodGroup').classList.remove('hidden');
      el('connectedCashGroup').classList.toggle('hidden', quote.paymentMethod !== 'CASH'); el('connectedCashReceived').value = ''; updateCashChangePreview(); window.PosValidation.clear(el('connectedCheckoutModal'));
       el('confirmConnectedSaleBtn').textContent = quote.paymentMethod === 'CREDIT' ? 'Facturar a crédito' : quote.priceChanged ? 'Confirmar precio y cobrar' : 'Cobrar orden';
      el('connectedCheckoutModal').classList.remove('hidden'); refreshed = true;
    } catch (error) { showAlert(window.PosMessages.fromError(error, 'No se pudo completar la operación. Inténtalo de nuevo.')); if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error); }
    finally { busy = false; el('confirmConnectedSaleBtn').disabled = false; if (refreshed) (quote.paymentMethod === 'CASH' ? el('connectedCashReceived') : el('confirmConnectedSaleBtn')).focus(); }
  }
  async function confirmPayment(id) {
    await perform('PAYMENT_CONFIRM', {}, (client, input) => client.confirmPayment(id, input));
  }
  async function cancelOrder(id) {
    await perform('ORDER_CANCEL', {}, (client, input) => client.cancelOrder(id, input));
  }
  const money = value => 'C$' + Number(value || 0).toFixed(2);
  function cashLoadStatus(message = '', loading = false) {
    const status = el('cashLoadStatus'), label = el('cashLoadMessage'), retry = el('retryCashLoadBtn');
    if (!status || !label || !retry) return;
    label.textContent = message;
    status.classList.toggle('hidden', !message);
    status.classList.toggle('is-error', Boolean(message) && !loading);
    retry.classList.toggle('hidden', !message || loading);
    retry.disabled = loading;
    for (const id of ['abrirCajaBtn', 'registrarEntradaBtn', 'registrarSalidaBtn', 'cerrarCajaBtn']) {
      const button = el(id);
      if (button) button.disabled = Boolean(message);
    }
  }
  function clearCashDataForRetry() {
    currentCash = null;
    displayedCashSessions = [];
    window.PosRuntime.setCash([]);
    for (const id of ['cajaAbrirBox', 'cajaAbiertaBox', 'cajaCentralBox']) el(id)?.classList.add('hidden');
    fillEmpty(el('cajaHistorialBody'), 8, 'Vuelve a intentar cargar Caja.');
    fillEmpty(el('cajaMovimientosBody'), 7, 'Vuelve a intentar cargar Caja.');
    fillEmpty(el('cajaOperacionesBody'), 7, 'Vuelve a intentar cargar Caja.');
    fillEmpty(el('cajaPendientesHistoricosBody'), 7, 'Vuelve a intentar cargar Caja.');
    for (const id of ['cajaCentralVentas', 'cajaCentralCobros', 'cajaCentralEsperado', 'cajaCentralDiferencia']) {
      const value = el(id);
      if (value) value.textContent = '—';
    }
  }
  function fillEmpty(body, columns, message) {
    const row = document.createElement('tr'), cell = document.createElement('td'); cell.colSpan = columns; cell.className = 'text-center'; cell.textContent = message; row.append(cell); body.replaceChildren(row);
  }
  function renderCentral(overview) {
    if (!overview || overview.businessId !== state().businessId) throw new window.PosApiError('CASH_RESPONSE_INVALID');
    salesFlow = overview.salesFlow; renderCheckoutMode();
    el('cajaCentralBox').classList.remove('hidden');
    const scopeLabel = overview.currentCashSessionId ? 'sesión actual' : 'historial general';
    el('cajaOperacionesTitulo').textContent = 'Operaciones para revisión (' + scopeLabel + ')';
    el('cajaMovimientosTitulo').textContent = 'Movimientos de efectivo (' + scopeLabel + ')';
    const visibleOperationTitle = [...document.querySelectorAll('#cajaCentralBox h3')].find(element => element !== el('cajaOperacionesTitulo') && element.textContent.trim().startsWith('Operaciones'));
    if (visibleOperationTitle) visibleOperationTitle.textContent = 'Operaciones para revisión (' + scopeLabel + ')';
    const displayScopeLabel = overview.currentCashSessionId ? 'sesi\u00f3n actual' : 'historial general';
    el('cajaOperacionesTitulo').textContent = 'Operaciones para revisi\u00f3n (' + displayScopeLabel + ')';
    el('cajaMovimientosTitulo').textContent = 'Movimientos de efectivo (' + displayScopeLabel + ')';
    if (visibleOperationTitle) visibleOperationTitle.textContent = 'Operaciones para revisi\u00f3n (' + displayScopeLabel + ')';
    el('cajaCentralVentas').textContent = money(overview.salesByUser.reduce((sum, item) => sum + Number(item.total), 0));
    el('cajaCentralCobros').textContent = money(overview.customerCollections);
    el('cajaCentralEsperado').textContent = money(overview.expectedAmount);
    el('cajaCentralDiferencia').textContent = money(overview.lastDifference);
    el('connectedSalesFlowSetting').classList.toggle('hidden', state().role !== 'ADMIN');
    el('connectedSalesFlow').value = salesFlow;
    const users = el('cajaVentasUsuarioBody');
    if (!overview.salesByUser.length) fillEmpty(users, 8, 'Sin ventas registradas.');
    else {
      users.replaceChildren();
      for (const item of overview.salesByUser) {
        const row = document.createElement('tr');
        for (const value of [item.userName, item.saleCount, money(item.cash), money(item.card), money(item.transfer), money(item.credit), money(item.collections), money(item.total)]) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
        users.append(row);
      }
    }
    pendingOrderDetails = new Map([...overview.pendingOrders, ...(overview.pendingHistoricalOrders || [])].map(order => [order.id, order]));
    const paymentRows = payments => payments.map(payment => ({ kind: 'payment', id: payment.id, date: payment.createdAt, reference: payment.kind === 'SUPPLIER_PAYMENT' ? 'Pago a proveedor · ' + (payment.supplierName || 'Proveedor') + (payment.invoiceNumber ? ' · Factura ' + payment.invoiceNumber : '') : (payment.kind === 'CUSTOMER_PAYMENT' ? 'Abono factura #' : 'Factura #') + payment.invoiceNumber, user: payment.seller, method: payment.paymentMethod === 'CARD' ? 'Tarjeta pendiente' : 'Transferencia pendiente', amount: payment.amount }));
    const orderRows = orders => orders.map(order => ({ kind: 'order', id: order.id, date: order.createdAt, reference: window.PosCashOrderSearch.summary(order), searchText: window.PosCashOrderSearch.searchValue(order), user: order.seller, method: order.clientId ? 'Crédito' : 'Por cobrar', amount: order.estimatedTotal }));
    const saleRows = sales => (sales || []).map(sale => ({ kind: 'sale', id: sale.id, date: sale.createdAt, reference: 'Factura #' + (sale.isHistorical ? (sale.originalInvoiceNumber || 'original no disponible') : sale.invoiceNumber), user: sale.seller, method: sale.paymentMethod === 'CARD' ? 'Tarjeta' : sale.paymentMethod === 'TRANSFER' ? 'Transferencia' : sale.paymentMethod === 'CREDIT' ? 'Crédito' : 'Efectivo', amount: sale.amount, isHistorical: sale.isHistorical === true }));
    const collectionRows = payments => (payments || []).map(payment => ({ kind: 'collection', id: payment.id, date: payment.createdAt, reference: 'Abono factura #' + payment.invoiceNumber, user: payment.seller, method: payment.paymentMethod === 'CARD' ? 'Tarjeta' : payment.paymentMethod === 'TRANSFER' ? 'Transferencia' : 'Efectivo', amount: payment.amount }));
    const renderOperationRows = (body, payments, orders, historical = false, additionalRows = []) => {
      if (!body) return;
       const pendingRows = [...paymentRows(payments), ...orderRows(orders)].sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
       const historyRows = [...additionalRows].sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
       const rows = [...pendingRows, ...historyRows];
      if (!rows.length) { fillEmpty(body, 7, historical ? 'Sin pendientes de sesiones anteriores.' : 'No hay pagos pendientes ni órdenes por cobrar.'); return; }
      body.replaceChildren();
      for (const item of rows) {
         const row = document.createElement('tr'); row.dataset.priority = item.kind === 'payment' || item.kind === 'order' ? '0' : '1';
        row.dataset.tableDate = window.PosTables.dateKey(item.date);
        if (item.kind === 'order') row.dataset.orderSearch = item.searchText;
        for (const value of [new Date(item.date).toLocaleString(), item.reference, item.user, item.method, money(item.amount), item.kind === 'payment' ? 'Pendiente de confirmación' : (historical ? 'Pendiente histórico · sin factura' : 'Orden pendiente · sin factura ni descuento de inventario')]) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
        if (item.kind === 'sale') row.cells[5].textContent = item.isHistorical ? 'Histórica · solo consulta' : 'Venta registrada';
        if (item.kind === 'collection') row.cells[5].textContent = 'Cobro registrado';
         const actions = document.createElement('td');
         const actionGroup = document.createElement('div'); actionGroup.className = 'cash-operation-actions';
         const addAction = (label, action, variant = 'success') => { const button = document.createElement('button'); button.type = 'button'; button.className = 'btn btn-sm btn-' + variant; button.textContent = label; button.dataset.action = action; button.dataset.id = item.id; actionGroup.append(button); };
         if (item.kind === 'payment') addAction('Confirmar recibido', 'confirm-payment');
         else if (item.kind === 'order') { addAction('Detalle', 'order-detail', 'info'); addAction('Cobrar', 'charge-order', 'success'); addAction('Cancelar', 'cancel-order', 'danger'); }
         actions.append(actionGroup); row.append(actions); body.append(row);
      }
    };
    const hasOpenSession = Boolean(overview.currentCashSessionId);
    renderOperationRows(el('cajaOperacionesBody'), overview.pendingPayments, overview.pendingOrders, false, [...saleRows(overview.operationSales), ...collectionRows(overview.operationCollections)]);
    const historicalPayments = hasOpenSession ? (overview.pendingHistoricalPayments || []) : [], historicalOrders = hasOpenSession ? (overview.pendingHistoricalOrders || []) : [];
    renderOperationRows(el('cajaPendientesHistoricosBody'), historicalPayments, historicalOrders, true);
    el('cajaPendientesHistoricosSection')?.classList.toggle('hidden', !hasOpenSession || (historicalPayments.length === 0 && historicalOrders.length === 0));
    const movementsBody = el('cajaMovimientosBody');
    if (!overview.movements.length) fillEmpty(movementsBody, 7, 'Sin movimientos registrados.');
    else {
      movementsBody.replaceChildren();
      for (const movement of overview.movements) {
        const method = movement.paymentMethod === 'CARD' ? 'Tarjeta' : movement.paymentMethod === 'TRANSFER' ? 'Transferencia' : movement.paymentMethod === 'CASH' ? 'Efectivo' : '';
        const movementTypes = { REVERSAL: 'Reversión', MANUAL_ENTRY: 'Ingreso manual', MANUAL_EXIT: 'Retiro manual', SALE: 'Venta', CUSTOMER_PAYMENT: 'Abono de cliente', SUPPLIER_PAYMENT: 'Pago a proveedor', EXPENSE: 'Gasto', PURCHASE: 'Pago de compra', PURCHASE_CANCEL: 'Devolución de compra', CUSTOMER_PAYMENT_VOID: 'Anulación de abono', SUPPLIER_PAYMENT_VOID: 'Anulación de pago' };
        const movementLabel = method || movementTypes[movement.type] || (movement.direction === 'IN' ? 'Ingreso' : movement.direction === 'OUT' ? 'Egreso' : 'Movimiento registrado');
        let status = movement.status === 'VOID' ? 'Anulado' : movement.status === 'PENDING' ? (method ? method + ' pendiente de confirmación' : 'Pendiente') : (method ? method + ' confirmado' : 'Confirmado');
        if (movement.status === 'CONFIRMED' && method && method !== 'Efectivo' && movement.confirmedBy) status += ' · ' + movement.confirmedBy + ' · ' + new Date(movement.confirmedAt).toLocaleString();
        const row = document.createElement('tr');
        row.dataset.tableDate = window.PosTables.dateKey(movement.createdAt);
        for (const value of [new Date(movement.createdAt).toLocaleString(), movementLabel, cashMovementDescription(movement.description), money(movement.amount), movement.userName, status]) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
         const actionCell = document.createElement('td');
         const actionGroup = document.createElement('div'); actionGroup.className = 'cash-operation-actions';
         if (movement.status === 'PENDING' && ['CARD', 'TRANSFER'].includes(movement.paymentMethod)) { const button = document.createElement('button'); button.type = 'button'; button.className = 'btn btn-sm btn-success'; button.textContent = 'Confirmar recibido'; button.dataset.action = 'confirm-payment'; button.dataset.id = movement.id; actionGroup.append(button); }
         actionCell.append(actionGroup); row.append(actionCell); movementsBody.append(row);
      }
    }
  }
  function mappedCash(value) {
    const optionalAmount = candidate => candidate === null || candidate === undefined ? null : Number(candidate);
    const openedAt = new Date(value.openedAt).toLocaleString(), closedAt = value.closedAt ? new Date(value.closedAt).toLocaleString() : null;
    return { connectedCloseData: { ...value, openedAt, closedAt, closedBy: value.closedBy || null }, id: value.id, businessId: value.businessId, isHistorical: value.isHistorical === true, sourceStatus: value.sourceStatus || null, estado: value.status === 'OPEN' ? 'abierta' : 'cerrada', efectivoInicial: Number(value.openingAmount), efectivoEsperado: optionalAmount(value.expectedAmount), efectivoReal: optionalAmount(value.countedAmount), diferencia: optionalAmount(value.difference), usuarioApertura: value.openedBy, usuarioCierre: value.closedBy || (value.isHistorical ? 'No registrado' : null), fechaApertura: openedAt, fechaAperturaTS: Date.parse(value.openedAt), fechaCierre: closedAt || (value.isHistorical ? 'No registrado' : null), fechaCierreTS: value.closedAt ? Date.parse(value.closedAt) : null, movimientos: (value.movements || []).map(m => ({ id: m.id, tipo: m.direction === 'IN' ? 'entrada' : 'salida', medioPago: m.payment_method, monto: Number(m.amount), concepto: m.description, usuario: m.user_name, fecha: new Date(m.created_at).toLocaleString(), fechaTS: Date.parse(m.created_at), estado: m.status === 'PENDING' ? 'pendiente' : m.status === 'CONFIRMED' ? 'confirmado' : 'void' })), connectedSales: (value.movements || []).filter(m => m.type === 'SALE' && m.status === 'CONFIRMED').reduce((sum, m) => sum + Number(m.amount), 0), connectedExpected: optionalAmount(value.expectedAmount) };
  }
  function renderCash(overview) {
    renderCajaViewBase();
    const latest = displayedCashSessions.find(value => value.estado === 'cerrada');
    const hint = el('cajaEfectivoInicialHint');
    if (hint && latest?.isHistorical && latest.efectivoEsperado === null) hint.textContent = 'La caja anterior es un registro histórico sin importe de cierre informado. Ingresa el efectivo real con el que comienza este turno.';
    for (const [index, session] of displayedCashSessions.filter(value => value.estado === 'cerrada').entries()) {
      if (session.diferencia === null) {
        const cell = el('cajaHistorialBody')?.rows[index]?.cells[6];
        if (cell) cell.style.color = 'var(--text-muted)';
      }
    }
    if (overview) renderCentral(overview);
    const range = window.PosPeriodFilters?.range('cash');
    for (const id of ['cajaMovimientosBody', 'cajaHistorialBody', 'cajaOperacionesBody', 'cajaPendientesHistoricosBody']) window.PosPeriodFilters?.filterTable(id, range);
    filterCashOrders();
  }
  function filterCashOrders() {
    const query = window.PosCashOrderSearch.normalize(el('cashOrderSearch')?.value || '').trim();
    const range = window.PosPeriodFilters?.range('cash');
    for (const id of ['cajaOperacionesBody', 'cajaPendientesHistoricosBody']) {
      for (const row of el(id)?.rows || []) {
        if (row.dataset.orderSearch === undefined) continue;
        const matchesQuery = !query || row.dataset.orderSearch.includes(query);
        const matchesPeriod = !range || range.error || !window.PosPeriodFilters?.matches || window.PosPeriodFilters.matches(row.dataset.tableDate, range);
        row.hidden = !matchesQuery || !matchesPeriod;
      }
    }
  }
  async function load(view) {
    if (activeScope !== scope()) { activeScope = scope(); quote = quoteInput = null; }
    showPending();
    if (view === 'salesView') {
      const [settings] = await Promise.all([
        api(client => client.salesFlow()),
        refreshNextInvoiceNumber(),
        window.PosClients.loadCreditClients()
      ]);
      salesFlow = settings.salesFlow; renderCheckoutMode();
    }
    if (view === 'clientsView') await window.PosClients.load(view);
    if (view === 'historyView') { markHistorySummaryLoading(); await loadHistory(); }
    if (view === 'cajaView') {
      cashLoadStatus('Cargando el historial de Caja…', true);
      clearCashDataForRetry();
      try {
        const [sessions, overview] = await Promise.all([pages('cashSessions'), api(client => client.cashOverview())]);
        currentCash = sessions.find(value => value.status === 'OPEN') || null;
        displayedCashSessions = sessions.map(mappedCash);
        window.PosRuntime.setCash(displayedCashSessions);
        renderCash(overview);
        cashLoadStatus();
        return true;
      } catch (failure) {
        clearCashDataForRetry();
        cashLoadStatus(window.PosMessages.fromError(failure, 'No se pudo cargar Caja. Revisa la conexión e inténtalo nuevamente.'));
        if (failure.code === 'INVALID_SESSION') window.PosConnected.handleError(failure);
        return false;
      }
    }
  }
  async function openCash() {
    const value = el('cajaEfectivoInicialInput').value;
    if (!/^\d+(?:\.\d{1,2})?$/.test(value)) { window.PosValidation.field('cajaEfectivoInicialInput', 'Ingresa el efectivo inicial, cero o mayor, con hasta dos decimales'); return; }
    await perform('OPEN_CASH', { openingAmount: value }, (client, input) => client.openCash(input));
  }
  async function closeDialog() {
    try { currentCash = await api(client => client.currentCash(true)); if (!currentCash) throw new window.PosApiError('CASH_CLOSED', 409); window.PosCashSummary.open(mappedCash(currentCash).connectedCloseData); }
    catch (error) { showAlert(window.PosMessages.fromError(error, 'No se pudo abrir el resumen de Caja. Actualiza la pantalla e inténtalo de nuevo.')); }
  }
  async function closeCash() {
    const value = el('cajaEfectivoRealInput').value;
    if (!/^\d+(?:\.\d{1,2})?$/.test(value)) { window.PosValidation.field('cajaEfectivoRealInput', 'Ingresa el efectivo contado, cero o mayor, con hasta dos decimales'); return; }
    if (!currentCash) return;
    await perform('CLOSE_CASH', { countedAmount: value }, (client, input) => client.closeCash(currentCash.id, input));
  }
  for (const id of ['registrarEntradaBtn', 'registrarSalidaBtn']) { el(id).disabled = false; el(id).title = 'Movimiento de efectivo confirmado en la caja abierta'; }
  el('retryCashLoadBtn')?.addEventListener('click', () => { void load('cajaView'); });
  el('descuentoPct').step = '0.0001';
  el('confCurrency').disabled = true; el('confCurrency').title = 'Moneda conectada C$. Configuración monetaria por negocio pendiente.';
  document.addEventListener('pos:period-changed', event => {
    if (event.detail?.id === 'history' && !el('historyView').classList.contains('hidden')) refreshHistorySummary();
  });
  document.addEventListener('connected:report-data-changed', () => {
    if (!el('historyView').classList.contains('hidden')) loadHistory({ refresh: true }).catch(error => setHistoryStatus(window.PosMessages.fromError(error, 'No se pudo actualizar el historial. Inténtalo de nuevo.')));
  });
  const auditTable = el('auditTableBody').closest('.history-table-container'); auditTable.previousElementSibling.classList.add('hidden'); auditTable.classList.add('hidden');
  const hideAuditTableTools = () => { const toolbar = auditTable.previousElementSibling; if (toolbar?.classList.contains('data-table-toolbar')) toolbar.classList.add('hidden'); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hideAuditTableTools, { once: true }); else hideAuditTableTools();
  el('currentSaleNumber').textContent = '—';
  el('cashOrderSearch')?.addEventListener('input', filterCashOrders);
  el('saleDetailInput')?.addEventListener('input', () => { saleDetailRevision++; });
  el('confirmConnectedSaleBtn').addEventListener('click', confirm); el('recoverSaleBtn').addEventListener('click', recover);
  el('connectedOrderPaymentMethod').addEventListener('change', refreshOrderQuote);
  el('connectedCashReceived').addEventListener('input', updateCashChangePreview);
  el('connectedCheckoutModal').querySelector('.close-modal-btn').addEventListener('click', () => { activeOrderId = null; quote = quoteInput = null; });
  const handleOperationAction = event => {
    const button = event.target.closest('button[data-action]'); if (!button) return;
    const id = button.dataset.id, action = button.dataset.action;
    if (action === 'confirm-payment') confirmPayment(id);
    if (action === 'charge-order') startOrderCharge(id);
    if (action === 'cancel-order') cancelOrder(id);
    if (action === 'order-detail') {
      const order = pendingOrderDetails.get(id); if (!order) return;
      const detail = order.items.map(item => item.name + ' × ' + Number(item.quantity) + (item.priceSnapshotAvailable && item.estimatedSubtotal !== null ? ' · C$' + item.estimatedSubtotal : ' · Precio histórico no disponible')).join('\n');
      showAlert('Orden #' + order.id + ' · Cliente: ' + window.PosCashOrderSearch.customerLabel(order) + ' · ' + order.seller + '\n' + detail + '\nEstimado al preparar: C$' + order.estimatedTotal + '. Precio y stock se volverán a validar al cobrar.');
    }
  };
  for (const id of ['cajaOperacionesBody', 'cajaPendientesHistoricosBody']) el(id)?.addEventListener('click', handleOperationAction);
  el('cajaMovimientosBody').addEventListener('click', event => { const button = event.target.closest('button[data-action="confirm-payment"]'); if (button) confirmPayment(button.dataset.id); });
  el('saveConnectedSalesFlow').addEventListener('click', async () => {
    const button = el('saveConnectedSalesFlow'); button.disabled = true;
    try {
      const value = await api(client => client.setSalesFlow(el('connectedSalesFlow').value));
      salesFlow = value.salesFlow; renderCheckoutMode(); el('connectedSalesFlowMessage').textContent = salesFlow === 'DIRECT' ? 'Venta directa activa. Cada vendedor cobra desde Venta.' : 'Cobro centralizado activo. Los vendedores preparan órdenes; un usuario con permiso de Caja las confirma y factura.';
      await load('cajaView');
    } catch (error) { showAlert(window.PosMessages.fromError(error, 'No se pudo actualizar la forma de cobro. Inténtalo de nuevo.')); if (error.code === 'INVALID_SESSION') window.PosConnected.handleError(error); }
    finally { button.disabled = false; }
  });
  window.addEventListener('storage', event => { if (event.key === activeScope) showPending(); });
  function reversePayment(type, id, method, status) {
    const title = type === 'customer' ? 'Revertir abono de cliente' : 'Revertir pago a proveedor';
    window.showAnularRegistro(title, status === 'PENDING' ? 'Se liberará el saldo reservado. No afecta efectivo.' : method === 'CASH' ? 'Se registrará la compensación en la caja actual. Los cierres anteriores se conservan.' : 'La compensación por el mismo medio debe realizarse fuera del POS.', reason => {
      const submit = externalRefundConfirmed => perform(type === 'customer' ? 'CUSTOMER_PAYMENT_VOID' : 'SUPPLIER_PAYMENT_VOID', { reason, externalRefundConfirmed }, (client, input) => client.reverseFinancialPayment(type, id, input));
      if (status === 'POSTED' && method !== 'CASH') window.showConfirm('¿Confirmas que el importe ya fue devuelto por el mismo medio fuera del POS? Esta acción solo registra la reversión contable.', () => submit(true));
      else submit(false);
    });
  }
  function manualCash(direction) {
    const amount = el('cajaMovimientoMonto').value, reason = el('cajaMovimientoConcepto').value.trim();
    window.PosValidation.clear(el('cajaMovimientoMonto').parentElement); window.PosValidation.clear(el('cajaMovimientoConcepto').parentElement);
    if (!/^\d+(?:\.\d{1,2})?$/.test(amount) || Number(amount) <= 0) { window.PosValidation.field('cajaMovimientoMonto', 'Ingresa un monto mayor que cero, con hasta dos decimales.'); return; }
    if (!reason || reason.length > 500) { window.PosValidation.field('cajaMovimientoConcepto', 'Ingresa el motivo, hasta 500 caracteres.'); return; }
    return perform('CASH_MANUAL', { direction, amount, reason }, (client, input) => client.manualCashMovement(input));
  }
  window.PosSales = Object.freeze({ manualCash, reversePayment, checkout, confirm, cancel, openCash, closeCash, closeDialog, load, searchHistory, renderCash, viewInvoice, performFinancial: perform, payReceivable: (id, data) => perform('CUSTOMER_PAYMENT', data, (client, input) => client.payReceivable(id, input)) });
})();
