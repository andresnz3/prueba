/* Build template. scripts/build-static.cjs inserts the closed static asset list and revision. */
'use strict';

const CACHE_NAME = 'pos-pwa-shell-800ae4d9e6d9c414';
const CACHE_PREFIX = 'pos-pwa-shell-';
// eslint-disable-next-line no-undef -- build-time list generated from the public static files.
const PRECACHE_URLS = ["/404.html","/api-client.js","/api-config.js","/app.js","/assets/pwa/pos-icon-192.png","/assets/pwa/pos-icon-512.png","/assets/pwa/pos-icon.svg","/assets/pwa/softventaweb-favicon-20261106-16.png","/assets/pwa/softventaweb-favicon-20261106-32.png","/assets/pwa/softventaweb-favicon-20261106-48.png","/assets/pwa/softventaweb-favicon-20261106.svg","/assets/pwa/softventaweb-pwa-20261106-512.png","/assets/pwa/softventaweb-touch-20261106-192.png","/cash-order-search.js","/connected-auth.js","/connected-clients.js","/connected-dashboard.js","/connected-expenses.js","/connected-inventory.js","/connected-migration-history.js","/connected-purchases.js","/connected-reports.js","/connected-sales.js","/dashboard-period.js","/data-tables.js","/icons.js","/index.html","/inicio/utm-cleanup.js","/local-auth.js","/local-cash-flow.js","/local-license-config.js","/local-license.js","/local-migration-export.js","/local-migration-preview.js","/manifest.webmanifest","/manifest.webmanifest?v=20261106","/offline.html","/period-filters.js","/pwa.js","/styles.css","/validation.js","/vendor/dexie/dexie.min.js","/vendor/fonts/inter-latin-ext-wght-normal.woff2","/vendor/fonts/inter-latin-wght-normal.woff2","/vendor/html2pdf/html2pdf.bundle.min.js","/vendor/html5-qrcode/html5-qrcode.min.js","/vendor/xlsx/xlsx.full.min.js"];
const OFFLINE_PAGE = '/offline.html';
const APP_PAGE = '/index.html';

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS)));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names
      .filter(name => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME)
      .map(name => caches.delete(name)));
  })());
});

async function networkNavigation(request) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);
  try {
    return await fetch(request, { signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname === '/api' || url.pathname.startsWith('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(request, { ignoreSearch: true });
      if (cached) return cached;
      try {
        return await networkNavigation(request);
      } catch {
        return (await cache.match(APP_PAGE)) || (await cache.match(OFFLINE_PAGE)) || Response.error();
      }
    })());
    return;
  }

  if (!PRECACHE_URLS.includes(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request, { ignoreSearch: true });
    if (cached) return cached;
    try {
      return await fetch(request);
    } catch {
      return new Response('', { status: 503, statusText: 'Offline' });
    }
  })());
});
