﻿'use strict';
/* global module */
(function attachCashOrderSearch(root) {
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  function customerLabel(order) {
    const value = order?.customerName || order?.clientName || order?.detail;
    return typeof value === 'string' && value.trim() ? value.trim() : 'Cliente general';
  }
  function searchValue(order) {
    const id = String(order?.id ?? '');
    return normalize([id, 'Pedido #' + id, order?.customerName, order?.clientName, order?.detail, ...(order?.items || []).map(item => item?.name)].join(' '));
  }
  function matches(order, query) {
    const needle = normalize(query).trim();
    return !needle || searchValue(order).includes(needle);
  }
  function summary(order) {
    const id = String(order?.id ?? '');
    const customer = customerLabel(order);
    const products = (order?.items || []).map(item => String(item?.name || 'Producto') + ' × ' + Number(item?.quantity || 0)).join(', ');
    return ['Pedido #' + id, customer, products].filter(Boolean).join(' · ');
  }
  const api = Object.freeze({ normalize, customerLabel, searchValue, matches, summary });
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PosCashOrderSearch = api;
})(globalThis);
